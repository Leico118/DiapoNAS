# Icône DiapoNAS v2 : style commun (anneaux gris, doré, halo) + symbole photo lisible.
import os, sys
from PIL import Image, ImageDraw

BG = (10, 10, 12, 255); GOLD = (217, 196, 163, 255); RING = (70, 66, 74, 255)

def mark(size, scale=1.0, bg=True, rounded=True):
    S = size * 4
    im = Image.new('RGBA', (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    if bg:
        if rounded: d.rounded_rectangle([0, 0, S - 1, S - 1], radius=int(S * 0.22), fill=BG)
        else: d.rectangle([0, 0, S, S], fill=BG)
    c = S / 2; R = S * 0.34 * scale
    glow = Image.new('RGBA', (S, S), (0, 0, 0, 0)); gd = ImageDraw.Draw(glow)
    for k in range(45):
        a0 = -50 - k * 1.5
        gd.pieslice([c - R, c - R, c + R, c + R], a0 - 1.6, a0, fill=(217, 196, 163, int(55 * (1 - k / 45) ** 1.6)))
    im = Image.alpha_composite(im, glow); d = ImageDraw.Draw(im)
    wr = int(S * 0.022 * scale); wg = int(S * 0.026 * scale)
    d.ellipse([c - R, c - R, c + R, c + R], outline=RING, width=wr)

    fw, fh, rad = 0.57 * R, 0.43 * R, int(0.11 * R)
    fx, fy = c - 0.08 * R, c + 0.08 * R          # photo de devant
    bx, by = fx + 0.18 * R, fy - 0.18 * R        # photo de derrière
    # photo de derrière (grise)
    d.rounded_rectangle([bx - fw, by - fh, bx + fw, by + fh], radius=rad, outline=RING, width=wr)
    # photo de devant : on masque l'arrière puis cadre doré
    d.rounded_rectangle([fx - fw, fy - fh, fx + fw, fy + fh], radius=rad, fill=BG, outline=GOLD, width=wg)
    # montagnes, découpées à l'intérieur du cadre
    m = Image.new('RGBA', (S, S), (0, 0, 0, 0)); md = ImageDraw.Draw(m)
    L, Rr, B = fx - fw, fx + fw, fy + fh
    pts = [(L, B - 0.10 * R), (fx - 0.22 * R, fy - 0.05 * R), (fx + 0.05 * R, fy + 0.22 * R),
           (fx + 0.22 * R, fy + 0.08 * R), (Rr, B - 0.02 * R)]
    md.line(pts, fill=GOLD, width=wg, joint='curve')
    for p in pts[1:-1]:
        r0 = wg / 2; md.ellipse([p[0] - r0, p[1] - r0, p[0] + r0, p[1] + r0], fill=GOLD)
    clip = Image.new('L', (S, S), 0)
    ImageDraw.Draw(clip).rounded_rectangle([L + wg / 2, fy - fh + wg / 2, Rr - wg / 2, B - wg / 2], radius=rad, fill=255)
    im.paste(m, (0, 0), Image.composite(m, Image.new('RGBA', (S, S)), clip).split()[3]); d = ImageDraw.Draw(im)
    # soleil = petit anneau gris + point doré (repris des autres icônes)
    sx, sy = fx + 0.26 * R, fy - 0.19 * R
    r = 0.12 * R; d.ellipse([sx - r, sy - r, sx + r, sy + r], outline=RING, width=wr)
    r = 0.055 * R; d.ellipse([sx - r, sy - r, sx + r, sy + r], fill=GOLD)
    return im.resize((size, size), Image.LANCZOS)

if __name__ == '__main__':
    res = sys.argv[1]
    for name, px in [('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192)]:
        os.makedirs(f'{res}/mipmap-{name}', exist_ok=True)
        mark(px).save(f'{res}/mipmap-{name}/ic_launcher.png')
        mark(px, rounded=False).save(f'{res}/mipmap-{name}/ic_launcher_round.png')
        mark(px * 108 // 48, 0.62, bg=False).save(f'{res}/mipmap-{name}/ic_launcher_foreground.png')
    out = Image.new('RGB', (1380, 600), (255, 255, 255))
    for i, p in enumerate(['/tmp/claude-0/icons/MindFilter/app/src/main/res/drawable-xxxhdpi/ic_launcher_art.png',
                           '/tmp/claude-0/icons/Finder-all-Infos/app/src/main/res/mipmap-xxxhdpi/ic_launcher_foreground.png', None]):
        im = Image.open(p).convert('RGBA') if p else mark(432, 0.62, bg=False)
        cv = Image.new('RGBA', (432, 432), BG); cv.alpha_composite(im)
        mk = Image.new('L', (432, 432), 0); ImageDraw.Draw(mk).ellipse([0, 0, 431, 431], fill=255)
        out.paste(cv.convert('RGB'), (14 + i * 456, 14), mk)
    # taille réelle sur l'écran d'accueil
    small = mark(144, rounded=True)
    out.paste(small, (14 + 2 * 456 + 144, 450), small)
    out.save(sys.argv[2])
