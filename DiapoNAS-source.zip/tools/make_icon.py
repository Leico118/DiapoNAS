# Icône DiapoNAS : même direction artistique que MindFilter et Radar.
import os, sys
from PIL import Image, ImageDraw

BG = (10, 10, 12, 255); GOLD = (217, 196, 163, 255); RING = (70, 66, 74, 255)

def mark(size, scale=1.0, bg=True, rounded=True):
    S = size * 4
    im = Image.new('RGBA', (S, S), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    if bg:
        if rounded: d.rounded_rectangle([0, 0, S - 1, S - 1], radius=int(S * 0.22), fill=BG)
        else: d.rectangle([0, 0, S, S], fill=BG)
    c = S / 2; R = S * 0.34 * scale
    # halo doré en haut à droite (comme les autres applis)
    glow = Image.new('RGBA', (S, S), (0, 0, 0, 0)); gd = ImageDraw.Draw(glow)
    for k in range(45):
        a0 = -50 - k * 1.5
        gd.pieslice([c - R, c - R, c + R, c + R], a0 - 1.6, a0, fill=(217, 196, 163, int(55 * (1 - k / 45) ** 1.6)))
    im = Image.alpha_composite(im, glow); d = ImageDraw.Draw(im)
    w_ring = int(S * 0.022 * scale); w_gold = int(S * 0.026 * scale)
    # grand anneau gris
    d.ellipse([c - R, c - R, c + R, c + R], outline=RING, width=w_ring)
    # photo principale (cadre doré)
    fw, fh, cy = 0.60 * R, 0.42 * R, c - 0.06 * R
    d.rounded_rectangle([c - fw, cy - fh, c + fw, cy + fh], radius=int(0.13 * R), outline=GOLD, width=w_gold)
    # photos voisines, de chaque côté (effet diaporama)
    for sgn in (-1, 1):
        x = c + sgn * 0.78 * R
        d.line([x, cy - 0.27 * R, x, cy + 0.27 * R], fill=GOLD, width=w_gold)
        for yy in (cy - 0.27 * R, cy + 0.27 * R):
            r0 = w_gold / 2; d.ellipse([x - r0, yy - r0, x + r0, yy + r0], fill=GOLD)
    # petit anneau gris + point doré central
    r = R * 0.22
    d.ellipse([c - r, cy - r, c + r, cy + r], outline=RING, width=w_ring)
    r = R * 0.10
    d.ellipse([c - r, cy - r, c + r, cy + r], fill=GOLD)
    # indicateur de diapositives sous la photo
    dy = cy + 0.64 * R
    for i, (dx, rr, col) in enumerate([(-0.17, 0.045, RING), (0, 0.065, GOLD), (0.17, 0.045, RING)]):
        x = c + dx * R; rr *= R
        d.ellipse([x - rr, dy - rr, x + rr, dy + rr], fill=col)
    return im.resize((size, size), Image.LANCZOS)

if __name__ == '__main__':
    res = sys.argv[1]
    for name, px in [('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192)]:
        os.makedirs(f'{res}/mipmap-{name}', exist_ok=True)
        mark(px).save(f'{res}/mipmap-{name}/ic_launcher.png')
        mark(px, rounded=False).save(f'{res}/mipmap-{name}/ic_launcher_round.png')
        fg = px * 108 // 48
        mark(fg, 0.62, bg=False).save(f'{res}/mipmap-{name}/ic_launcher_foreground.png')
    # aperçu
    out = Image.new('RGB', (1380, 460), (255, 255, 255))
    for i, p in enumerate(['/tmp/claude-0/icons/MindFilter/app/src/main/res/drawable-xxxhdpi/ic_launcher_art.png',
                           '/tmp/claude-0/icons/Finder-all-Infos/app/src/main/res/mipmap-xxxhdpi/ic_launcher_foreground.png', None]):
        im = Image.open(p).convert('RGBA') if p else mark(432, 0.62, bg=False)
        cv = Image.new('RGBA', (432, 432), BG); cv.alpha_composite(im)
        m = Image.new('L', (432, 432), 0); ImageDraw.Draw(m).ellipse([0, 0, 431, 431], fill=255)
        out.paste(cv.convert('RGB'), (14 + i * 456, 14), m)
    out.save(sys.argv[2])
