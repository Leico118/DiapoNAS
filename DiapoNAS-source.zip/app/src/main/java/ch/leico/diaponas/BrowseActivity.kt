package ch.leico.diaponas

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.util.concurrent.Executors

/** Navigation dans les dossiers du NAS pour choisir ceux du diaporama. */
class BrowseActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var root: String
    private var current = ""
    private var entries: List<Smb.Entry> = emptyList()
    private var loadToken = 0

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private lateinit var textPath: TextView
    private lateinit var list: ListView
    private lateinit var progress: ProgressBar
    private lateinit var textMessage: TextView
    private lateinit var btnAdd: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browse)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        prefs = Prefs(this)
        root = Smb.rootUrl(prefs)

        textPath = findViewById(R.id.textPath)
        list = findViewById(R.id.listFolders)
        progress = findViewById(R.id.progress)
        textMessage = findViewById(R.id.textMessage)
        btnAdd = findViewById(R.id.btnAdd)

        list.setOnItemClickListener { _, _, pos, _ ->
            entries.getOrNull(pos)?.let { open(it.url) }
        }

        btnAdd.setOnClickListener {
            if (current == root) return@setOnClickListener
            prefs.addFolder(current)
            Toast.makeText(this, getString(R.string.folder_added, Smb.pretty(current)), Toast.LENGTH_SHORT).show()
            finish()
        }

        findViewById<View>(R.id.btnShare).setOnClickListener { askShareName() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                goUpOrFinish()
            }
        })

        open(root)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            goUpOrFinish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdownNow()
    }

    private fun goUpOrFinish() {
        if (current == root || current.isEmpty()) {
            finish()
            return
        }
        val trimmed = current.trimEnd('/')
        val parent = trimmed.substring(0, trimmed.lastIndexOf('/') + 1)
        open(if (parent.length < root.length) root else parent)
    }

    private fun open(url: String) {
        current = url
        val token = ++loadToken
        textPath.text = if (url == root) getString(R.string.nas_root, root.removePrefix("smb://").trimEnd('/'))
        else Smb.pretty(url)
        btnAdd.isEnabled = url != root
        btnAdd.text = if (url == root) getString(R.string.btn_add_pick) else getString(R.string.btn_add_folder)
        progress.visibility = View.VISIBLE
        textMessage.visibility = View.GONE
        entries = emptyList()
        list.adapter = null

        io.execute {
            try {
                val result = Smb.listFolders(prefs, url)
                main.post {
                    if (token != loadToken || isFinishing) return@post
                    progress.visibility = View.GONE
                    entries = result
                    list.adapter = ArrayAdapter(this, R.layout.item_folder, R.id.textName, result.map { it.name })
                    if (result.isEmpty()) {
                        textMessage.visibility = View.VISIBLE
                        textMessage.text = getString(if (url == root) R.string.no_share else R.string.no_subfolder)
                    }
                }
            } catch (t: Throwable) {
                main.post {
                    if (token != loadToken || isFinishing) return@post
                    progress.visibility = View.GONE
                    textMessage.visibility = View.VISIBLE
                    val hint = if (url == root) "\n\n" + getString(R.string.root_error_hint) else ""
                    textMessage.text = Smb.explain(t) + hint
                }
            }
        }
    }

    /** Pour les NAS qui refusent de lister leurs partages : on tape le nom directement. */
    private fun askShareName() {
        val input = EditText(this).apply {
            hint = getString(R.string.share_hint)
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = android.widget.FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_open_share)
            .setMessage(R.string.share_message)
            .setView(box)
            .setPositiveButton(R.string.open) { _, _ ->
                val name = input.text.toString().trim().trim('/', '\\')
                if (name.isNotEmpty()) open(root + name.replace('\\', '/') + "/")
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
