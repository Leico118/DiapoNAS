package ch.leico.diaponas

import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import android.os.Handler
import android.os.Looper
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import java.util.concurrent.Executors

/** Navigation dans les dossiers du NAS pour choisir ceux du diaporama. */
class BrowseActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var root: String
    private var current = ""
    private var entries: List<Smb.Entry> = emptyList()
    private var loadToken = 0
    private val selected = LinkedHashSet<String>()
    private var adapter: FolderAdapter? = null

    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private lateinit var textPath: TextView
    private lateinit var list: ListView
    private lateinit var progress: ProgressBar
    private lateinit var textMessage: TextView
    private lateinit var btnAdd: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browse)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        prefs = Prefs(this)
        root = Smb.rootUrl(prefs)

        textPath = findViewById(R.id.textPath)
        list = findViewById(R.id.listFolders)
        progress = findViewById(R.id.progress)
        textMessage = findViewById(R.id.textMessage)
        btnAdd = findViewById(R.id.btnAdd)

        list.setOnItemClickListener { _, _, pos, _ ->
            val e = entries.getOrNull(pos) ?: return@setOnItemClickListener
            if (selected.isNotEmpty()) toggle(e.url) else open(e.url)
        }
        // Appui long : sélectionner un dossier (puis toucher les autres pour en ajouter)
        list.setOnItemLongClickListener { _, _, pos, _ ->
            entries.getOrNull(pos)?.let { toggle(it.url) }
            true
        }

        btnAdd.setOnClickListener {
            if (selected.isNotEmpty()) {
                selected.forEach { prefs.addFolder(it) }
                Toast.makeText(this, getString(R.string.folders_added, selected.size), Toast.LENGTH_SHORT).show()
                finish()
                return@setOnClickListener
            }
            if (current == root) return@setOnClickListener
            prefs.addFolder(current)
            Toast.makeText(this, getString(R.string.folder_added, Smb.pretty(current)), Toast.LENGTH_SHORT).show()
            finish()
        }

        findViewById<View>(R.id.btnShare).setOnClickListener { askShareName() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (selected.isNotEmpty()) clearSelection() else goUpOrFinish()
            }
        })

        open(root)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            if (selected.isNotEmpty()) clearSelection() else goUpOrFinish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdownNow()
    }

    private fun toggle(url: String) {
        if (!selected.remove(url)) selected.add(url)
        adapter?.notifyDataSetChanged()
        updateButton()
    }

    private fun clearSelection() {
        selected.clear()
        adapter?.notifyDataSetChanged()
        updateButton()
    }

    private fun updateButton() {
        when {
            selected.isNotEmpty() -> {
                btnAdd.isEnabled = true
                btnAdd.text = resources.getQuantityString(R.plurals.btn_add_selected, selected.size, selected.size)
            }
            current == root -> {
                btnAdd.isEnabled = false
                btnAdd.text = getString(R.string.btn_add_pick)
            }
            else -> {
                btnAdd.isEnabled = true
                btnAdd.text = getString(R.string.btn_add_folder)
            }
        }
    }

    /** Liste des dossiers, avec une coche sur ceux qui sont sélectionnés. */
    private inner class FolderAdapter(items: List<Smb.Entry>) :
        ArrayAdapter<Smb.Entry>(this@BrowseActivity, R.layout.item_folder, items) {

        private val selectedBg = ColorUtils.setAlphaComponent(
            ContextCompat.getColor(this@BrowseActivity, R.color.brand), 50
        )

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val v = convertView ?: layoutInflater.inflate(R.layout.item_folder, parent, false)
            val e = getItem(position)!!
            val isSel = e.url in selected
            v.findViewById<TextView>(R.id.textName).text = e.name
            v.findViewById<View>(R.id.check).visibility = if (isSel) View.VISIBLE else View.GONE
            v.setBackgroundColor(if (isSel) selectedBg else Color.TRANSPARENT)
            return v
        }
    }

    private fun goUpOrFinish() {
        if (current == root || current.isEmpty()) {
            finish()
            return
        }
        val trimmed = current.trimEnd('/')
        val parent = trimmed.substring(0, trimmed.lastIndexOf('/') + 1)
        open(if (parent.length < root.length) root else parent)
    }

    private fun open(url: String) {
        current = url
        val token = ++loadToken
        textPath.text = if (url == root) getString(R.string.nas_root, root.removePrefix("smb://").trimEnd('/'))
        else Smb.pretty(url)
        selected.clear()
        updateButton()
        progress.visibility = View.VISIBLE
        textMessage.visibility = View.GONE
        entries = emptyList()
        adapter = null
        list.adapter = null

        io.execute {
            try {
                val result = Smb.listFolders(prefs, url)
                main.post {
                    if (token != loadToken || isFinishing) return@post
                    progress.visibility = View.GONE
                    entries = result
                    adapter = FolderAdapter(result).also { list.adapter = it }
                    if (result.isEmpty()) {
                        textMessage.visibility = View.VISIBLE
                        textMessage.text = getString(if (url == root) R.string.no_share else R.string.no_subfolder)
                    }
                }
            } catch (t: Throwable) {
                main.post {
                    if (token != loadToken || isFinishing) return@post
                    progress.visibility = View.GONE
                    textMessage.visibility = View.VISIBLE
                    val hint = if (url == root) "\n\n" + getString(R.string.root_error_hint) else ""
                    textMessage.text = Smb.explain(t) + hint
                }
            }
        }
    }

    /** Pour les NAS qui refusent de lister leurs partages : on tape le nom directement. */
    private fun askShareName() {
        val input = EditText(this).apply {
            hint = getString(R.string.share_hint)
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = android.widget.FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.btn_open_share)
            .setMessage(R.string.share_message)
            .setView(box)
            .setPositiveButton(R.string.open) { _, _ ->
                val name = input.text.toString().trim().trim('/', '\\')
                if (name.isNotEmpty()) open(root + name.replace('\\', '/') + "/")
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
