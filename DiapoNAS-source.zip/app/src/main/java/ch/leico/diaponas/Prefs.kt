package ch.leico.diaponas

import android.content.Context

/** Réglages de l'appli, enregistrés sur le téléphone. */
class Prefs(ctx: Context) {
    private val sp = ctx.applicationContext.getSharedPreferences("diaponas", Context.MODE_PRIVATE)

    var host: String
        get() = sp.getString("host", "") ?: ""
        set(v) = sp.edit().putString("host", v.trim()).apply()

    var user: String
        get() = sp.getString("user", "") ?: ""
        set(v) = sp.edit().putString("user", v.trim()).apply()

    var password: String
        get() = sp.getString("password", "") ?: ""
        set(v) = sp.edit().putString("password", v).apply()

    var folders: List<String>
        get() = (sp.getString("folders", "") ?: "").split("\n").filter { it.isNotBlank() }
        set(v) = sp.edit().putString("folders", v.distinct().joinToString("\n")).apply()

    var intervalSec: Int
        get() = sp.getInt("interval", 8)
        set(v) = sp.edit().putInt("interval", v).apply()

    var random: Boolean
        get() = sp.getBoolean("random", true)
        set(v) = sp.edit().putBoolean("random", v).apply()

    var subfolders: Boolean
        get() = sp.getBoolean("subfolders", true)
        set(v) = sp.edit().putBoolean("subfolders", v).apply()

    var fill: Boolean
        get() = sp.getBoolean("fill", false)
        set(v) = sp.edit().putBoolean("fill", v).apply()

    var showName: Boolean
        get() = sp.getBoolean("showName", false)
        set(v) = sp.edit().putBoolean("showName", v).apply()

    var includeVideos: Boolean
        get() = sp.getBoolean("videos", true)
        set(v) = sp.edit().putBoolean("videos", v).apply()

    /** À la fin d'une vidéo ou d'un GIF : passer au suivant (sinon, ça tourne en boucle). */
    var autoNext: Boolean
        get() = sp.getBoolean("autoNext", true)
        set(v) = sp.edit().putBoolean("autoNext", v).apply()

    var videoSound: Boolean
        get() = sp.getBoolean("sound", true)
        set(v) = sp.edit().putBoolean("sound", v).apply()

    /** Index dans [Transitions.LABELS]. */
    var transition: Int
        get() = sp.getInt("transition", 0)
        set(v) = sp.edit().putInt("transition", v).apply()

    fun addFolder(url: String) {
        folders = folders + url
    }

    fun removeFolder(url: String) {
        folders = folders - url
    }
}

object Transitions {
    const val FADE = 0
    const val SLIDE = 1
    const val ZOOM = 2
    const val KEN_BURNS = 3
    const val RANDOM = 4
    const val NONE = 5

    val LABELS = listOf(
        "Fondu",
        "Glissement",
        "Zoom",
        "Fondu + mouvement lent (Ken Burns)",
        "Aléatoire",
        "Aucune"
    )
}
