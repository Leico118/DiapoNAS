package ch.leico.diaponas

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var editHost: TextInputEditText
    private lateinit var editUser: TextInputEditText
    private lateinit var editPassword: TextInputEditText
    private lateinit var folderList: LinearLayout
    private lateinit var textNoFolder: TextView
    private lateinit var textInterval: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        editHost = findViewById(R.id.editHost)
        editUser = findViewById(R.id.editUser)
        editPassword = findViewById(R.id.editPassword)
        folderList = findViewById(R.id.folderList)
        textNoFolder = findViewById(R.id.textNoFolder)
        textInterval = findViewById(R.id.textInterval)

        editHost.setText(prefs.host)
        editUser.setText(prefs.user)
        editPassword.setText(prefs.password)

        val slider = findViewById<Slider>(R.id.sliderInterval)
        slider.value = prefs.intervalSec.coerceIn(3, 120).toFloat()
        showInterval(prefs.intervalSec)
        slider.addOnChangeListener { _, value, _ ->
            prefs.intervalSec = value.toInt()
            showInterval(value.toInt())
        }

        val spinner = findViewById<Spinner>(R.id.spinnerTransition)
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Transitions.LABELS)
        spinner.setSelection(prefs.transition.coerceIn(0, Transitions.LABELS.size - 1))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, pos: Int, id: Long) {
                prefs.transition = pos
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        bindSwitch(R.id.switchRandom, prefs.random) { prefs.random = it }
        bindSwitch(R.id.switchSub, prefs.subfolders) { prefs.subfolders = it }
        bindSwitch(R.id.switchVideos, prefs.includeVideos) { prefs.includeVideos = it }
        bindSwitch(R.id.switchAutoNext, prefs.autoNext) { prefs.autoNext = it }
        bindSwitch(R.id.switchSound, prefs.videoSound) { prefs.videoSound = it }
        bindSwitch(R.id.switchFill, prefs.fill) { prefs.fill = it }
        bindSwitch(R.id.switchName, prefs.showName) { prefs.showName = it }

        findViewById<android.view.View>(R.id.btnBrowse).setOnClickListener {
            saveServer()
            if (prefs.host.isBlank()) {
                Toast.makeText(this, R.string.need_host, Toast.LENGTH_LONG).show()
                editHost.requestFocus()
            } else {
                startActivity(Intent(this, BrowseActivity::class.java))
            }
        }

        findViewById<android.view.View>(R.id.btnStart).setOnClickListener {
            saveServer()
            when {
                prefs.host.isBlank() -> Toast.makeText(this, R.string.need_host, Toast.LENGTH_LONG).show()
                prefs.folders.isEmpty() -> Toast.makeText(this, R.string.need_folder, Toast.LENGTH_LONG).show()
                else -> startActivity(Intent(this, SlideshowActivity::class.java))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        refreshFolders()
    }

    override fun onPause() {
        super.onPause()
        saveServer()
    }

    private fun saveServer() {
        prefs.host = editHost.text?.toString() ?: ""
        prefs.user = editUser.text?.toString() ?: ""
        prefs.password = editPassword.text?.toString() ?: ""
    }

    private fun bindSwitch(id: Int, value: Boolean, onChange: (Boolean) -> Unit) {
        val sw = findViewById<MaterialSwitch>(id)
        sw.isChecked = value
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
    }

    private fun showInterval(sec: Int) {
        textInterval.text = if (sec < 60) getString(R.string.interval_sec, sec)
        else getString(R.string.interval_min, sec / 60, sec % 60)
    }

    private fun refreshFolders() {
        folderList.removeAllViews()
        val folders = prefs.folders
        textNoFolder.visibility = if (folders.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        val inflater = LayoutInflater.from(this)
        for (url in folders) {
            val row = inflater.inflate(R.layout.item_folder_selected, folderList, false)
            row.findViewById<TextView>(R.id.textFolder).text = Smb.pretty(url)
            row.findViewById<ImageButton>(R.id.btnRemove).setOnClickListener {
                prefs.removeFolder(url)
                refreshFolders()
            }
            folderList.addView(row)
        }
    }
}
