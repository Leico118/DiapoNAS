package ch.leico.diaponas

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.os.Build
import androidx.exifinterface.media.ExifInterface
import jcifs.CIFSContext
import jcifs.config.PropertyConfiguration
import jcifs.context.BaseContext
import jcifs.smb.NtlmPasswordAuthenticator
import jcifs.smb.SmbAuthException
import jcifs.smb.SmbFile
import java.io.ByteArrayInputStream
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.nio.ByteBuffer
import java.util.Properties
import kotlin.math.max
import kotlin.math.min

/** Tout ce qui parle au NAS (partage Windows / SMB1 et SMB2, compatible anciens Synology). */
object Smb {

    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "bmp", "gif", "heic", "heif")

    @Volatile private var cached: CIFSContext? = null
    @Volatile private var cachedKey = ""

    data class Entry(val name: String, val url: String)

    @Synchronized
    fun context(p: Prefs): CIFSContext {
        val key = "${p.host}|${p.user}|${p.password}"
        cached?.let { if (key == cachedKey) return it }
        val props = Properties().apply {
            // SMB1 accepté pour les vieux NAS, SMB2 si le NAS le propose
            setProperty("jcifs.smb.client.minVersion", "SMB1")
            setProperty("jcifs.smb.client.maxVersion", "SMB210")
            setProperty("jcifs.smb.client.connTimeout", "10000")
            setProperty("jcifs.smb.client.responseTimeout", "30000")
            setProperty("jcifs.smb.client.soTimeout", "35000")
            setProperty("jcifs.smb.client.ipcSigningEnforced", "false")
            setProperty("jcifs.smb.client.dfs.disabled", "true")
            setProperty("jcifs.resolveOrder", "DNS,BCAST")
        }
        val base = BaseContext(PropertyConfiguration(props))
        val ctx = if (p.user.isBlank()) base.withGuestCrendentials()
        else base.withCredentials(NtlmPasswordAuthenticator(p.user, p.password))
        cached = ctx
        cachedKey = key
        return ctx
    }

    fun rootUrl(p: Prefs): String {
        var h = p.host.trim()
            .removePrefix("smb://")
            .removePrefix("\\\\")
            .replace('\\', '/')
            .trimEnd('/')
        if (h.contains('/')) h = h.substringBefore('/')
        return "smb://$h/"
    }

    /** Affichage lisible : « /photo/Vacances ». */
    fun pretty(url: String): String {
        val s = url.removePrefix("smb://")
        val path = s.substringAfter('/', "")
        return "/" + path.trimEnd('/')
    }

    private fun skip(name: String): Boolean {
        val n = name.trimEnd('/')
        return n.startsWith(".") || n.startsWith("@") || n.startsWith("#") || n.endsWith("$")
    }

    /** Liste les sous-dossiers (ou les partages si on est à la racine du NAS). */
    fun listFolders(p: Prefs, url: String): List<Entry> {
        val dir = SmbFile(url, context(p))
        try {
            val out = ArrayList<Entry>()
            for (f in dir.listFiles()) {
                try {
                    val name = f.name
                    if (name.endsWith("/") && !skip(name)) {
                        out.add(Entry(name.trimEnd('/'), f.path))
                    }
                } finally {
                    f.close()
                }
            }
            out.sortBy { it.name.lowercase() }
            return out
        } finally {
            dir.close()
        }
    }

    fun isImage(name: String): Boolean =
        IMAGE_EXT.contains(name.substringAfterLast('.', "").lowercase())

    /**
     * Parcourt les dossiers et appelle [onBatch] au fur et à mesure qu'il trouve des photos.
     * [cancelled] permet d'arrêter le parcours.
     */
    fun scan(
        p: Prefs,
        roots: List<String>,
        recursive: Boolean,
        cancelled: () -> Boolean,
        onBatch: (List<String>) -> Unit,
        onError: (String, Throwable) -> Unit
    ) {
        val ctx = context(p)
        val stack = ArrayDeque<String>()
        roots.reversed().forEach { stack.addLast(it) }
        while (stack.isNotEmpty() && !cancelled()) {
            val url = stack.removeLast()
            val found = ArrayList<String>()
            val subdirs = ArrayList<String>()
            var dir: SmbFile? = null
            try {
                dir = SmbFile(url, ctx)
                for (f in dir.listFiles()) {
                    try {
                        val name = f.name
                        if (name.endsWith("/")) {
                            if (recursive && !skip(name)) subdirs.add(f.path)
                        } else if (!name.startsWith(".") && isImage(name)) {
                            found.add(f.path)
                        }
                    } finally {
                        f.close()
                    }
                }
            } catch (t: Throwable) {
                onError(url, t)
            } finally {
                try { dir?.close() } catch (_: Throwable) {}
            }
            found.sortBy { it.lowercase() }
            if (found.isNotEmpty()) onBatch(found)
            subdirs.sortByDescending { it.lowercase() }
            subdirs.forEach { stack.addLast(it) }
        }
    }

    /** Télécharge une photo et la réduit à la taille de l'écran. */
    fun loadBitmap(p: Prefs, url: String, screenW: Int, screenH: Int): Bitmap? {
        val f = SmbFile(url, context(p))
        val bytes = try {
            f.inputStream.use { it.readBytes() }
        } finally {
            f.close()
        }
        val longSide = max(screenW, screenH)
        val shortSide = min(screenW, screenH)

        fun sample(w: Int, h: Int): Int {
            var s = 1
            while (max(w, h) / (s * 2) >= longSide && min(w, h) / (s * 2) >= shortSide) s *= 2
            return s
        }

        if (Build.VERSION.SDK_INT >= 28) {
            try {
                val src = ImageDecoder.createSource(ByteBuffer.wrap(bytes))
                return ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                    decoder.setTargetSampleSize(sample(info.size.width, info.size.height))
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                }
            } catch (_: Throwable) {
                // on retente avec l'ancienne méthode ci-dessous
            }
        }

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0) return null
        val opts = BitmapFactory.Options().apply { inSampleSize = sample(bounds.outWidth, bounds.outHeight) }
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return null

        val orientation = try {
            ExifInterface(ByteArrayInputStream(bytes))
                .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } catch (_: Throwable) {
            ExifInterface.ORIENTATION_NORMAL
        }
        val m = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return bmp
        }
        val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        if (rotated != bmp) bmp.recycle()
        return rotated
    }

    /** Message d'erreur compréhensible. */
    fun explain(t: Throwable): String {
        var c: Throwable? = t
        while (c != null) {
            when (c) {
                is SmbAuthException -> return "Identifiant ou mot de passe refusé par le NAS."
                is UnknownHostException -> return "Adresse du NAS introuvable. Essaie avec son adresse IP (ex. 192.168.1.20)."
                is ConnectException -> return "Le NAS ne répond pas. Vérifie l'adresse, que le NAS est allumé et que tu es sur le Wi-Fi de la maison."
                is SocketTimeoutException -> return "Le NAS met trop de temps à répondre."
            }
            c = c.cause
        }
        return "Erreur : " + (t.message ?: t.javaClass.simpleName)
    }
}
