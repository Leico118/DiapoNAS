package ch.leico.diaponas

import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSpec
import jcifs.smb.SmbFile
import jcifs.smb.SmbRandomAccessFile
import java.io.IOException
import kotlin.math.min

/** Lit une vidéo directement sur le NAS, morceau par morceau (permet d'avancer / reculer). */
@OptIn(UnstableApi::class)
class SmbDataSource(private val prefs: Prefs) : BaseDataSource(true) {

    private var file: SmbFile? = null
    private var raf: SmbRandomAccessFile? = null
    private var uri: Uri? = null
    private var remaining = 0L
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        uri = dataSpec.uri
        transferInitializing(dataSpec)
        val url = dataSpec.uri.getQueryParameter("u") ?: throw IOException("Adresse de la vidéo manquante")
        val f = SmbFile(url, Smb.context(prefs))
        file = f
        val r = SmbRandomAccessFile(f, "r")
        raf = r
        val len = r.length()
        if (dataSpec.position > len) throw IOException("Position hors du fichier")
        r.seek(dataSpec.position)
        remaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) dataSpec.length
        else len - dataSpec.position
        opened = true
        transferStarted(dataSpec)
        return remaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (remaining <= 0L) return C.RESULT_END_OF_INPUT
        val n = raf!!.read(buffer, offset, min(remaining, length.toLong()).toInt())
        if (n <= 0) return C.RESULT_END_OF_INPUT
        remaining -= n
        bytesTransferred(n)
        return n
    }

    override fun getUri(): Uri? = uri

    override fun close() {
        uri = null
        try { raf?.close() } catch (_: Throwable) {}
        try { file?.close() } catch (_: Throwable) {}
        raf = null
        file = null
        if (opened) {
            opened = false
            transferEnded()
        }
    }
}
