package ch.leico.diaponas

import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.random.Random

class SlideshowActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private val main = Handler(Looper.getMainLooper())
    private lateinit var scanner: ExecutorService
    private lateinit var loader: ExecutorService
    @Volatile private var destroyed = false

    // Vues
    private lateinit var stage: View
    private lateinit var imageA: ImageView
    private lateinit var imageB: ImageView
    private lateinit var front: ImageView
    private lateinit var back: ImageView
    private lateinit var overlay: View
    private lateinit var textStatus: TextView
    private lateinit var textCaption: TextView
    private lateinit var textInfo: TextView
    private lateinit var btnPlay: ImageButton

    // Photos trouvées (utilisées uniquement sur le fil principal)
    private val images = ArrayList<String>()
    private val played = HashSet<String>()
    private var seqIndex = -1
    private var scanDone = false
    private var scanErrors = 0
    private var lastScanError = ""

    // Historique pour revenir en arrière
    private val history = ArrayList<String>()
    private var histPos = -1

    // Photo suivante préparée à l'avance
    private var nextUrl: String? = null
    private var nextBmp: Bitmap? = null
    private var loadToken = 0
    private var waitingToShow = false
    private var failures = 0
    private var shownCount = 0

    private var paused = false
    private var userPaused = false
    private val running = ArrayList<Animator>()

    private val tick = Runnable { advance() }
    private val hideOverlay = Runnable { overlay.visibility = View.GONE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slideshow)
        prefs = Prefs(this)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideSystemBars()

        stage = findViewById(R.id.stage)
        imageA = findViewById(R.id.imageA)
        imageB = findViewById(R.id.imageB)
        front = imageA
        back = imageB
        overlay = findViewById(R.id.overlay)
        textStatus = findViewById(R.id.textStatus)
        textCaption = findViewById(R.id.textCaption)
        textInfo = findViewById(R.id.textInfo)
        btnPlay = findViewById(R.id.btnPlay)

        val scale = if (prefs.fill) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
        imageA.scaleType = scale
        imageB.scaleType = scale

        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<View>(R.id.btnNext).setOnClickListener { manualNext(); pokeOverlay() }
        findViewById<View>(R.id.btnPrev).setOnClickListener { manualPrev(); pokeOverlay() }
        btnPlay.setOnClickListener {
            userPaused = !userPaused
            if (userPaused) pauseShow() else resumeShow()
            updatePlayButton()
            pokeOverlay()
        }

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                toggleOverlay()
                return true
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (abs(vx) > abs(vy) && abs(vx) > 600) {
                    if (vx < 0) manualNext() else manualPrev()
                    return true
                }
                return false
            }
        })
        findViewById<View>(R.id.root).setOnTouchListener { v, ev ->
            if (ev.action == MotionEvent.ACTION_UP) v.performClick()
            detector.onTouchEvent(ev)
            true
        }

        scanner = Executors.newSingleThreadExecutor()
        loader = Executors.newSingleThreadExecutor()

        textStatus.text = getString(R.string.searching)
        startScan()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onPause() {
        super.onPause()
        pauseShow()
    }

    override fun onResume() {
        super.onResume()
        if (!userPaused) resumeShow()
    }

    override fun onDestroy() {
        super.onDestroy()
        destroyed = true
        main.removeCallbacksAndMessages(null)
        running.forEach { it.cancel() }
        scanner.shutdownNow()
        loader.shutdownNow()
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    // ---------- Recherche des photos ----------

    private fun startScan() {
        val roots = prefs.folders
        val recursive = prefs.subfolders
        scanner.execute {
            Smb.scan(
                prefs, roots, recursive,
                cancelled = { destroyed },
                onBatch = { batch -> main.post { onFound(batch) } },
                onError = { _, t -> main.post { scanErrors++; lastScanError = Smb.explain(t) } }
            )
            main.post {
                scanDone = true
                if (images.isEmpty()) {
                    textStatus.text = if (scanErrors > 0) lastScanError else getString(R.string.no_photo)
                }
            }
        }
    }

    private fun onFound(batch: List<String>) {
        if (destroyed) return
        val wasEmpty = images.isEmpty()
        images.addAll(batch)
        if (wasEmpty) {
            waitingToShow = true
            queueNext()
        }
        if (shownCount == 0) textStatus.text = getString(R.string.searching_count, images.size)
    }

    // ---------- Choix de la photo suivante ----------

    private fun chooseNext(): String? {
        if (histPos + 1 < history.size) return history[histPos + 1]
        if (images.isEmpty()) return null
        if (!prefs.random) {
            seqIndex = (seqIndex + 1) % images.size
            return images[seqIndex]
        }
        if (images.size == 1) return images[0]
        if (played.size >= images.size) {
            played.clear()
            history.getOrNull(histPos)?.let { played.add(it) }
        }
        val current = history.getOrNull(histPos)
        repeat(40) {
            val u = images[Random.nextInt(images.size)]
            if (u !in played && u != current) return u
        }
        return images.firstOrNull { it !in played && it != current } ?: images[Random.nextInt(images.size)]
    }

    private fun queueNext() {
        if (destroyed) return
        val url = chooseNext() ?: return
        nextUrl = url
        nextBmp = null
        load(url) { bmp ->
            if (url != nextUrl) return@load
            nextBmp = bmp
            if (waitingToShow) showNext()
        }
    }

    private fun load(url: String, onReady: (Bitmap) -> Unit) {
        val token = ++loadToken
        val w = stage.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val h = stage.height.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels
        loader.execute {
            val result = try {
                Result.success(Smb.loadBitmap(prefs, url, w, h))
            } catch (t: Throwable) {
                Result.failure(t)
            }
            main.post {
                if (destroyed || token != loadToken) return@post
                val bmp = result.getOrNull()
                if (bmp != null) {
                    failures = 0
                    onReady(bmp)
                } else {
                    // Photo illisible : on l'écarte et on passe à une autre
                    failures++
                    images.remove(url)
                    if (history.getOrNull(histPos + 1) == url) history.removeAt(histPos + 1)
                    if (failures > 25 || images.isEmpty()) {
                        val err = result.exceptionOrNull()
                        textStatus.text = if (err != null) Smb.explain(err) else getString(R.string.load_failed)
                        textStatus.visibility = View.VISIBLE
                    } else {
                        queueNext()
                    }
                }
            }
        }
    }

    // ---------- Défilement ----------

    private fun advance() {
        waitingToShow = true
        if (nextBmp != null) showNext()
        else if (nextUrl == null) queueNext()
    }

    private fun showNext() {
        val bmp = nextBmp ?: return
        val url = nextUrl ?: return
        waitingToShow = false
        nextBmp = null
        nextUrl = null

        if (histPos + 1 < history.size && history[histPos + 1] == url) {
            histPos++
        } else {
            while (history.size > histPos + 1) history.removeAt(history.size - 1)
            history.add(url)
            if (history.size > 300) history.removeAt(0)
            histPos = history.size - 1
        }
        played.add(url)
        display(bmp, url, forward = true)
        queueNext()
        scheduleTick()
    }

    private fun manualNext() {
        main.removeCallbacks(tick)
        advance()
    }

    private fun manualPrev() {
        if (histPos <= 0) return
        main.removeCallbacks(tick)
        val url = history[histPos - 1]
        // On abandonne la photo préparée : elle sera rechargée ensuite
        nextUrl = null
        nextBmp = null
        waitingToShow = false
        load(url) { bmp ->
            histPos--
            display(bmp, url, forward = false)
            queueNext()
            scheduleTick()
        }
    }

    private fun scheduleTick() {
        main.removeCallbacks(tick)
        if (!paused) main.postDelayed(tick, prefs.intervalSec * 1000L + TRANSITION_MS)
    }

    private fun pauseShow() {
        paused = true
        main.removeCallbacks(tick)
        running.forEach { if (it.isRunning) it.pause() }
    }

    private fun resumeShow() {
        if (!paused) return
        paused = false
        running.forEach { if (it.isPaused) it.resume() }
        if (shownCount > 0) scheduleTick()
    }

    // ---------- Affichage et transitions ----------

    private fun display(bmp: Bitmap, url: String, forward: Boolean) {
        running.forEach { it.cancel() }
        running.clear()

        val incoming = back
        val outgoing = front
        outgoing.alpha = 1f
        resetView(incoming)
        incoming.setImageBitmap(bmp)
        incoming.bringToFront()

        textStatus.visibility = View.GONE
        shownCount++

        val name = Smb.pretty(url)
        textInfo.text = name
        if (prefs.showName) {
            textCaption.visibility = View.VISIBLE
            textCaption.text = name.substringAfterLast('/')
        } else {
            textCaption.visibility = View.GONE
        }

        var type = prefs.transition
        if (type == Transitions.RANDOM) type = listOf(
            Transitions.FADE, Transitions.SLIDE, Transitions.ZOOM, Transitions.KEN_BURNS
        ).random()
        if (shownCount == 1 && type == Transitions.SLIDE) type = Transitions.FADE

        val w = stage.width.toFloat().takeIf { it > 0 } ?: resources.displayMetrics.widthPixels.toFloat()
        val dir = if (forward) 1f else -1f
        val anims = ArrayList<Animator>()

        when (type) {
            Transitions.FADE -> {
                anims += ObjectAnimator.ofFloat(incoming, View.ALPHA, 0f, 1f)
            }
            Transitions.SLIDE -> {
                anims += ObjectAnimator.ofFloat(incoming, View.TRANSLATION_X, w * dir, 0f)
                anims += ObjectAnimator.ofFloat(outgoing, View.TRANSLATION_X, 0f, -w * dir)
            }
            Transitions.ZOOM -> {
                anims += ObjectAnimator.ofFloat(incoming, View.ALPHA, 0f, 1f)
                anims += ObjectAnimator.ofFloat(incoming, View.SCALE_X, 1.25f, 1f)
                anims += ObjectAnimator.ofFloat(incoming, View.SCALE_Y, 1.25f, 1f)
            }
            Transitions.KEN_BURNS -> {
                anims += ObjectAnimator.ofFloat(incoming, View.ALPHA, 0f, 1f)
            }
            else -> { /* aucune transition */ }
        }

        if (anims.isNotEmpty()) {
            val set = AnimatorSet().apply {
                playTogether(anims)
                duration = TRANSITION_MS
                interpolator = DecelerateInterpolator()
            }
            running += set
            set.start()
        }

        if (type == Transitions.KEN_BURNS) {
            // Lent zoom avec léger déplacement pendant tout l'affichage
            val total = prefs.intervalSec * 1000L + TRANSITION_MS * 2
            val zoomIn = Random.nextBoolean()
            val from = if (zoomIn) 1.0f else 1.15f
            val to = if (zoomIn) 1.15f else 1.0f
            val shift = w * 0.04f * (if (Random.nextBoolean()) 1 else -1)
            val kb = AnimatorSet().apply {
                playTogether(
                    ObjectAnimator.ofFloat(incoming, View.SCALE_X, from, to),
                    ObjectAnimator.ofFloat(incoming, View.SCALE_Y, from, to),
                    ObjectAnimator.ofFloat(incoming, View.TRANSLATION_X, -shift / 2, shift / 2)
                )
                duration = total
                interpolator = LinearInterpolator()
            }
            running += kb
            kb.start()
        }

        if (paused) running.forEach { it.pause() }

        // Libère l'ancienne photo une fois la transition terminée
        val gen = shownCount
        main.postDelayed({
            if (gen == shownCount && !destroyed) {
                outgoing.setImageDrawable(null)
                resetView(outgoing)
            }
        }, TRANSITION_MS + 100)

        front = incoming
        back = outgoing
    }

    private fun resetView(v: ImageView) {
        v.alpha = 1f
        v.translationX = 0f
        v.scaleX = 1f
        v.scaleY = 1f
    }

    // ---------- Commandes ----------

    private fun toggleOverlay() {
        if (overlay.visibility == View.VISIBLE) {
            main.removeCallbacks(hideOverlay)
            overlay.visibility = View.GONE
        } else {
            overlay.visibility = View.VISIBLE
            updatePlayButton()
            pokeOverlay()
        }
    }

    private fun pokeOverlay() {
        main.removeCallbacks(hideOverlay)
        main.postDelayed(hideOverlay, 4000)
    }

    private fun updatePlayButton() {
        btnPlay.setImageResource(
            if (userPaused) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause
        )
        btnPlay.contentDescription = getString(if (userPaused) R.string.play else R.string.pause)
    }

    companion object {
        private const val TRANSITION_MS = 1000L
    }
}
