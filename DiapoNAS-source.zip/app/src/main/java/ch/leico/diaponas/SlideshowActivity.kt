package ch.leico.diaponas

import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.drawable.Animatable2
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.random.Random

@OptIn(UnstableApi::class)
class SlideshowActivity : AppCompatActivity() {

    /** Un élément prêt à être affiché. */
    private sealed class Prepared(val url: String) {
        class Still(url: String, val bmp: Bitmap) : Prepared(url)
        class Anim(url: String, val drawable: Drawable) : Prepared(url)
        class Video(url: String) : Prepared(url)
    }

    private lateinit var prefs: Prefs
    private val main = Handler(Looper.getMainLooper())
    private lateinit var scanner: ExecutorService
    private lateinit var loader: ExecutorService
    @Volatile private var destroyed = false

    // Vues
    private lateinit var stage: View
    private lateinit var imageA: ImageView
    private lateinit var imageB: ImageView
    private lateinit var playerView: PlayerView
    private lateinit var player: ExoPlayer
    private var currentView: View? = null
    private lateinit var overlay: View
    private lateinit var textStatus: TextView
    private lateinit var textCaption: TextView
    private lateinit var textInfo: TextView
    private lateinit var btnPlay: ImageButton
    private lateinit var seekRow: View
    private lateinit var seekBar: SeekBar
    private lateinit var textPos: TextView
    private lateinit var textDur: TextView
    private var dragging = false

    // Fichiers trouvés (utilisés uniquement sur le fil principal)
    private val images = ArrayList<String>()
    private val played = HashSet<String>()
    private var seqIndex = -1
    private var scanErrors = 0
    private var lastScanError = ""

    // Historique pour revenir en arrière
    private val history = ArrayList<String>()
    private var histPos = -1

    // Élément suivant préparé à l'avance
    private var nextUrl: String? = null
    private var nextItem: Prepared? = null
    private var loadToken = 0
    private var waitingToShow = false
    private var failures = 0
    private var shownCount = 0

    // Élément en cours
    private var current: Prepared? = null
    private var currentAnim: Drawable? = null
    private var pendingAdvance = false

    private var paused = false
    private var userPaused = false
    private val running = ArrayList<Animator>()

    private val tick = Runnable { advance() }
    private val hideOverlay = Runnable { overlay.visibility = View.GONE }
    private val progressTick = object : Runnable {
        override fun run() {
            updateProgress()
            if (overlay.visibility == View.VISIBLE && current is Prepared.Video) main.postDelayed(this, 500)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slideshow)
        prefs = Prefs(this)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideSystemBars()

        stage = findViewById(R.id.stage)
        imageA = findViewById(R.id.imageA)
        imageB = findViewById(R.id.imageB)
        playerView = findViewById(R.id.playerView)
        overlay = findViewById(R.id.overlay)
        textStatus = findViewById(R.id.textStatus)
        textCaption = findViewById(R.id.textCaption)
        textInfo = findViewById(R.id.textInfo)
        btnPlay = findViewById(R.id.btnPlay)
        seekRow = findViewById(R.id.seekRow)
        seekBar = findViewById(R.id.seekBar)
        textPos = findViewById(R.id.textPos)
        textDur = findViewById(R.id.textDur)

        val scale = if (prefs.fill) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
        imageA.scaleType = scale
        imageB.scaleType = scale

        setupPlayer()

        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<View>(R.id.btnNext).setOnClickListener { manualNext(); pokeOverlay() }
        findViewById<View>(R.id.btnPrev).setOnClickListener { manualPrev(); pokeOverlay() }
        btnPlay.setOnClickListener {
            userPaused = !userPaused
            if (userPaused) pauseShow() else resumeShow()
            updatePlayButton()
            pokeOverlay()
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val dur = player.duration
                    if (dur > 0) textPos.text = fmt(dur * progress / 1000)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {
                dragging = true
                main.removeCallbacks(hideOverlay)
            }
            override fun onStopTrackingTouch(sb: SeekBar) {
                dragging = false
                val dur = player.duration
                if (dur > 0) player.seekTo(dur * sb.progress / 1000)
                pokeOverlay()
            }
        })

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                toggleOverlay()
                return true
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (abs(vx) > abs(vy) && abs(vx) > 600) {
                    if (vx < 0) manualNext() else manualPrev()
                    return true
                }
                return false
            }
        })
        findViewById<View>(R.id.root).setOnTouchListener { v, ev ->
            if (ev.action == MotionEvent.ACTION_UP) v.performClick()
            detector.onTouchEvent(ev)
            true
        }

        scanner = Executors.newSingleThreadExecutor()
        loader = Executors.newSingleThreadExecutor()

        textStatus.text = getString(R.string.searching)
        startScan()
    }

    private fun setupPlayer() {
        val dsFactory = DataSource.Factory { SmbDataSource(prefs) }
        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory))
            .build()
        player.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            prefs.videoSound
        )
        player.volume = if (prefs.videoSound) 1f else 0f
        player.repeatMode = if (prefs.autoNext) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ONE
        playerView.player = player
        playerView.resizeMode = if (prefs.fill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        else AspectRatioFrameLayout.RESIZE_MODE_FIT

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && current is Prepared.Video) onMediaFinished()
                if (state == Player.STATE_READY) updateProgress()
            }
            override fun onPlayerError(error: PlaybackException) {
                val cur = current as? Prepared.Video ?: return
                images.remove(cur.url)
                failures++
                if (failures > 25 || images.isEmpty()) {
                    textStatus.text = getString(R.string.load_failed)
                    textStatus.visibility = View.VISIBLE
                    return
                }
                Toast.makeText(this@SlideshowActivity, R.string.video_error, Toast.LENGTH_SHORT).show()
                advance()
            }
        })
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onPause() {
        super.onPause()
        pauseShow()
    }

    override fun onResume() {
        super.onResume()
        if (!userPaused) resumeShow()
    }

    override fun onDestroy() {
        super.onDestroy()
        destroyed = true
        main.removeCallbacksAndMessages(null)
        running.forEach { it.cancel() }
        stopAnim()
        player.release()
        scanner.shutdownNow()
        loader.shutdownNow()
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    // ---------- Recherche des fichiers ----------

    private fun startScan() {
        val roots = prefs.folders
        val recursive = prefs.subfolders
        val videos = prefs.includeVideos
        scanner.execute {
            Smb.scan(
                prefs, roots, recursive, videos,
                cancelled = { destroyed },
                onBatch = { batch -> main.post { onFound(batch) } },
                onError = { _, t -> main.post { scanErrors++; lastScanError = Smb.explain(t) } }
            )
            main.post {
                if (images.isEmpty() && !destroyed) {
                    textStatus.text = if (scanErrors > 0) lastScanError else getString(R.string.no_photo)
                }
            }
        }
    }

    private fun onFound(batch: List<String>) {
        if (destroyed) return
        val wasEmpty = images.isEmpty()
        images.addAll(batch)
        if (wasEmpty) {
            waitingToShow = true
            queueNext()
        }
        if (shownCount == 0) textStatus.text = getString(R.string.searching_count, images.size)
    }

    // ---------- Choix de l'élément suivant ----------

    private fun chooseNext(): String? {
        if (histPos + 1 < history.size) return history[histPos + 1]
        if (images.isEmpty()) return null
        if (!prefs.random) {
            seqIndex = (seqIndex + 1) % images.size
            return images[seqIndex]
        }
        if (images.size == 1) return images[0]
        if (played.size >= images.size) {
            played.clear()
            history.getOrNull(histPos)?.let { played.add(it) }
        }
        val cur = history.getOrNull(histPos)
        repeat(40) {
            val u = images[Random.nextInt(images.size)]
            if (u !in played && u != cur) return u
        }
        return images.firstOrNull { it !in played && it != cur } ?: images[Random.nextInt(images.size)]
    }

    private fun queueNext() {
        if (destroyed) return
        val url = chooseNext() ?: return
        nextUrl = url
        nextItem = null
        load(url) { item ->
            if (url != nextUrl) return@load
            nextItem = item
            if (waitingToShow) showNext()
        }
    }

    private fun load(url: String, onReady: (Prepared) -> Unit) {
        val token = ++loadToken
        if (Smb.isVideo(url)) {
            // Les vidéos se lisent en continu depuis le NAS : rien à précharger
            main.post { if (!destroyed && token == loadToken) onReady(Prepared.Video(url)) }
            return
        }
        val w = stage.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val h = stage.height.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels
        loader.execute {
            val result: Result<Prepared?> = try {
                var item: Prepared? = null
                if (Smb.isGif(url) && Build.VERSION.SDK_INT >= 28) {
                    when (val d = Smb.loadAnimated(prefs, url, w, h)) {
                        is AnimatedImageDrawable -> item = Prepared.Anim(url, d)
                        is BitmapDrawable -> item = Prepared.Still(url, d.bitmap)
                        else -> {}
                    }
                }
                if (item == null) item = Smb.loadBitmap(prefs, url, w, h)?.let { Prepared.Still(url, it) }
                Result.success(item)
            } catch (t: Throwable) {
                Result.failure(t)
            }
            main.post {
                if (destroyed || token != loadToken) return@post
                val item = result.getOrNull()
                if (item != null) {
                    failures = 0
                    onReady(item)
                } else {
                    // Fichier illisible : on l'écarte et on passe à un autre
                    failures++
                    images.remove(url)
                    if (history.getOrNull(histPos + 1) == url) history.removeAt(histPos + 1)
                    if (failures > 25 || images.isEmpty()) {
                        val err = result.exceptionOrNull()
                        textStatus.text = if (err != null) Smb.explain(err) else getString(R.string.load_failed)
                        textStatus.visibility = View.VISIBLE
                    } else {
                        queueNext()
                    }
                }
            }
        }
    }

    // ---------- Défilement ----------

    private fun advance() {
        pendingAdvance = false
        main.removeCallbacks(tick)
        waitingToShow = true
        if (nextItem != null) showNext()
        else if (nextUrl == null) queueNext()
    }

    /** Fin d'une vidéo ou d'un GIF. */
    private fun onMediaFinished() {
        if (!prefs.autoNext) return
        if (paused) {
            pendingAdvance = true
            return
        }
        advance()
    }

    private fun showNext() {
        val item = nextItem ?: return
        waitingToShow = false
        nextItem = null
        nextUrl = null
        val url = item.url

        if (histPos + 1 < history.size && history[histPos + 1] == url) {
            histPos++
        } else {
            while (history.size > histPos + 1) history.removeAt(history.size - 1)
            history.add(url)
            if (history.size > 300) history.removeAt(0)
            histPos = history.size - 1
        }
        played.add(url)
        display(item, forward = true)
        queueNext()
    }

    private fun manualNext() {
        advance()
    }

    private fun manualPrev() {
        if (histPos <= 0) return
        main.removeCallbacks(tick)
        val url = history[histPos - 1]
        // On abandonne l'élément préparé : il sera rechargé ensuite
        nextUrl = null
        nextItem = null
        waitingToShow = false
        load(url) { item ->
            histPos--
            display(item, forward = false)
            queueNext()
        }
    }

    private fun scheduleTick() {
        main.removeCallbacks(tick)
        if (!paused && current is Prepared.Still) {
            main.postDelayed(tick, prefs.intervalSec * 1000L + TRANSITION_MS)
        }
    }

    private fun pauseShow() {
        paused = true
        main.removeCallbacks(tick)
        running.forEach { if (it.isRunning) it.pause() }
        if (current is Prepared.Video) player.pause()
        if (Build.VERSION.SDK_INT >= 28) (currentAnim as? AnimatedImageDrawable)?.stop()
    }

    private fun resumeShow() {
        if (!paused) return
        paused = false
        running.forEach { if (it.isPaused) it.resume() }
        when (current) {
            is Prepared.Video -> player.play()
            is Prepared.Anim -> if (Build.VERSION.SDK_INT >= 28) (currentAnim as? AnimatedImageDrawable)?.start()
            is Prepared.Still -> scheduleTick()
            null -> {}
        }
        if (pendingAdvance) advance()
    }

    // ---------- Affichage et transitions ----------

    private fun stopAnim() {
        if (Build.VERSION.SDK_INT >= 28) {
            (currentAnim as? AnimatedImageDrawable)?.let {
                it.clearAnimationCallbacks()
                it.stop()
            }
        }
        currentAnim = null
    }

    private fun stopVideo() {
        player.stop()
        player.clearMediaItems()
        playerView.visibility = View.INVISIBLE
        resetView(playerView)
    }

    private fun display(item: Prepared, forward: Boolean) {
        running.forEach { it.cancel() }
        running.clear()
        main.removeCallbacks(tick)
        stopAnim()
        pendingAdvance = false

        val outgoing = currentView
        val incoming: View = when (item) {
            is Prepared.Video -> playerView
            else -> if (outgoing === imageA) imageB else imageA
        }

        // Nettoie ce qui n'est ni l'ancien ni le nouvel élément (navigation rapide)
        if (playerView !== outgoing && playerView !== incoming) stopVideo()
        for (iv in listOf(imageA, imageB)) {
            if (iv !== outgoing && iv !== incoming) {
                iv.setImageDrawable(null)
                resetView(iv)
            }
        }
        outgoing?.alpha = 1f

        resetView(incoming)
        incoming.visibility = View.VISIBLE
        when (item) {
            is Prepared.Still -> (incoming as ImageView).setImageBitmap(item.bmp)
            is Prepared.Anim -> {
                (incoming as ImageView).setImageDrawable(item.drawable)
                if (Build.VERSION.SDK_INT >= 28) startAnim(item.drawable as AnimatedImageDrawable)
            }
            is Prepared.Video -> startVideo(item.url)
        }
        incoming.bringToFront()
        current = item
        currentView = incoming

        textStatus.visibility = View.GONE
        shownCount++

        val name = Smb.pretty(item.url)
        textInfo.text = name
        if (prefs.showName) {
            textCaption.visibility = View.VISIBLE
            textCaption.text = name.substringAfterLast('/')
            textCaption.bringToFront()
        } else {
            textCaption.visibility = View.GONE
        }
        val isVideo = item is Prepared.Video
        seekRow.visibility = if (isVideo) View.VISIBLE else View.GONE
        if (isVideo && overlay.visibility == View.VISIBLE) {
            main.removeCallbacks(progressTick)
            main.post(progressTick)
        }
        overlay.bringToFront()

        var type = prefs.transition
        if (type == Transitions.RANDOM) type = listOf(
            Transitions.FADE, Transitions.SLIDE, Transitions.ZOOM, Transitions.KEN_BURNS
        ).random()
        if (shownCount == 1 && type == Transitions.SLIDE) type = Transitions.FADE
        // Le mouvement lent ne s'applique qu'aux photos fixes
        if (type == Transitions.KEN_BURNS && item !is Prepared.Still) type = Transitions.FADE
        // Vidéo suivie d'une vidéo : même lecteur, pas de transition possible
        if (incoming === outgoing) type = Transitions.NONE

        val w = stage.width.toFloat().takeIf { it > 0 } ?: resources.displayMetrics.widthPixels.toFloat()
        val dir = if (forward) 1f else -1f
        val anims = ArrayList<Animator>()

        when (type) {
            Transitions.FADE, Transitions.KEN_BURNS -> {
                anims += ObjectAnimator.ofFloat(incoming, View.ALPHA, 0f, 1f)
            }
            Transitions.SLIDE -> {
                anims += ObjectAnimator.ofFloat(incoming, View.TRANSLATION_X, w * dir, 0f)
                if (outgoing != null) anims += ObjectAnimator.ofFloat(outgoing, View.TRANSLATION_X, 0f, -w * dir)
            }
            Transitions.ZOOM -> {
                anims += ObjectAnimator.ofFloat(incoming, View.ALPHA, 0f, 1f)
                anims += ObjectAnimator.ofFloat(incoming, View.SCALE_X, 1.25f, 1f)
                anims += ObjectAnimator.ofFloat(incoming, View.SCALE_Y, 1.25f, 1f)
            }
            else -> { /* aucune transition */ }
        }

        if (anims.isNotEmpty()) {
            val set = AnimatorSet().apply {
                playTogether(anims)
                duration = TRANSITION_MS
                interpolator = DecelerateInterpolator()
            }
            running += set
            set.start()
        }

        if (type == Transitions.KEN_BURNS) {
            // Lent zoom avec léger déplacement pendant tout l'affichage
            val total = prefs.intervalSec * 1000L + TRANSITION_MS * 2
            val zoomIn = Random.nextBoolean()
            val from = if (zoomIn) 1.0f else 1.15f
            val to = if (zoomIn) 1.15f else 1.0f
            val shift = w * 0.04f * (if (Random.nextBoolean()) 1 else -1)
            val kb = AnimatorSet().apply {
                playTogether(
                    ObjectAnimator.ofFloat(incoming, View.SCALE_X, from, to),
                    ObjectAnimator.ofFloat(incoming, View.SCALE_Y, from, to),
                    ObjectAnimator.ofFloat(incoming, View.TRANSLATION_X, -shift / 2, shift / 2)
                )
                duration = total
                interpolator = LinearInterpolator()
            }
            running += kb
            kb.start()
        }

        if (paused) running.forEach { it.pause() }

        // Libère l'ancien élément une fois la transition terminée
        val gen = shownCount
        main.postDelayed({
            if (gen == shownCount && !destroyed && outgoing != null && outgoing !== incoming) {
                if (outgoing === playerView) stopVideo()
                else if (outgoing is ImageView) {
                    outgoing.setImageDrawable(null)
                    resetView(outgoing)
                }
            }
        }, TRANSITION_MS + 100)

        scheduleTick()
    }

    @RequiresApi(28)
    private fun startAnim(d: AnimatedImageDrawable) {
        d.repeatCount = if (prefs.autoNext) 0 else AnimatedImageDrawable.REPEAT_INFINITE
        d.registerAnimationCallback(object : Animatable2.AnimationCallback() {
            override fun onAnimationEnd(drawable: Drawable?) {
                if (drawable === currentAnim) main.post { onMediaFinished() }
            }
        })
        currentAnim = d
        if (!paused) d.start()
    }

    private fun startVideo(url: String) {
        player.setMediaItem(MediaItem.fromUri(Smb.videoUri(url)))
        player.prepare()
        player.playWhenReady = !paused
    }

    private fun resetView(v: View) {
        v.alpha = 1f
        v.translationX = 0f
        v.scaleX = 1f
        v.scaleY = 1f
    }

    // ---------- Commandes ----------

    private fun toggleOverlay() {
        if (overlay.visibility == View.VISIBLE) {
            main.removeCallbacks(hideOverlay)
            overlay.visibility = View.GONE
        } else {
            overlay.visibility = View.VISIBLE
            overlay.bringToFront()
            updatePlayButton()
            main.removeCallbacks(progressTick)
            main.post(progressTick)
            pokeOverlay()
        }
    }

    private fun pokeOverlay() {
        main.removeCallbacks(hideOverlay)
        if (!dragging) main.postDelayed(hideOverlay, if (current is Prepared.Video) 5000 else 4000)
    }

    private fun updateProgress() {
        if (current !is Prepared.Video || dragging) return
        val dur = player.duration
        val pos = player.currentPosition
        if (dur > 0 && dur != C.TIME_UNSET) {
            textDur.text = fmt(dur)
            textPos.text = fmt(pos)
            seekBar.progress = (pos * 1000 / dur).toInt()
        } else {
            textDur.text = "–:––"
            textPos.text = fmt(pos)
            seekBar.progress = 0
        }
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%d:%02d", m, sec)
    }

    private fun updatePlayButton() {
        btnPlay.setImageResource(
            if (userPaused) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause
        )
        btnPlay.contentDescription = getString(if (userPaused) R.string.play else R.string.pause)
    }

    companion object {
        private const val TRANSITION_MS = 1000L
    }
}
