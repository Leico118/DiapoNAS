package ch.leico.diaponas

import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.drawable.Animatable2
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

@OptIn(UnstableApi::class)
class SlideshowActivity : AppCompatActivity() {

    /** Un élément prêt à être affiché. */
    private sealed class Prepared(val url: String) {
        class Still(url: String, val bmp: Bitmap) : Prepared(url)
        class Anim(url: String, val drawable: Drawable) : Prepared(url)
        class Video(url: String) : Prepared(url)
    }

    private lateinit var prefs: Prefs
    private val main = Handler(Looper.getMainLooper())
    private lateinit var scanner: ExecutorService
    private lateinit var loader: ExecutorService
    @Volatile private var destroyed = false

    // Vues
    private lateinit var stage: View
    private lateinit var imageA: ImageView
    private lateinit var imageB: ImageView
    private lateinit var playerView: PlayerView
    private lateinit var player: ExoPlayer
    private var currentView: View? = null
    private lateinit var overlay: View
    private lateinit var spinner: View
    private lateinit var textStatus: TextView
    private lateinit var textCaption: TextView
    private lateinit var textInfo: TextView
    private lateinit var btnPlay: ImageButton
    private lateinit var seekRow: View
    private lateinit var seekBar: SeekBar
    private lateinit var textPos: TextView
    private lateinit var textDur: TextView
    private var dragging = false

    // Fichiers trouvés (utilisés uniquement sur le fil principal)
    private val images = ArrayList<String>()
    private val played = HashSet<String>()
    private var seqIndex = -1
    private var scanErrors = 0
    private var lastScanError = ""

    /**
     * Liste de lecture : ce qui a été montré ET ce qui est prévu ensuite.
     * [histPos] = élément affiché, [target] = élément qu'on attend d'afficher (-1 si aucun).
     */
    private val history = ArrayList<String>()
    private var histPos = -1
    private var target = -1
    private var targetForward = true
    private var targetManual = false

    // Éléments déjà chargés (autour de la position actuelle) et chargements en cours
    private val cache = HashMap<String, Prepared>()
    private val inFlight = HashSet<String>()
    @Volatile private var wanted: Set<String> = emptySet()
    private var failures = 0
    private var shownCount = 0

    // Élément en cours
    private var current: Prepared? = null
    private var currentAnim: Drawable? = null
    private var pendingAdvance = false

    private var paused = false
    private var userPaused = false
    private val running = ArrayList<Animator>()

    private val tick = Runnable { goNext(manual = false) }
    private val hideOverlay = Runnable { overlay.visibility = View.GONE }
    private val showSpinner = Runnable { spinner.visibility = View.VISIBLE }
    private val progressTick = object : Runnable {
        override fun run() {
            updateProgress()
            if (overlay.visibility == View.VISIBLE && current is Prepared.Video) main.postDelayed(this, 500)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_slideshow)
        prefs = Prefs(this)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideSystemBars()

        stage = findViewById(R.id.stage)
        imageA = findViewById(R.id.imageA)
        imageB = findViewById(R.id.imageB)
        playerView = findViewById(R.id.playerView)
        overlay = findViewById(R.id.overlay)
        spinner = findViewById(R.id.spinner)
        textStatus = findViewById(R.id.textStatus)
        textCaption = findViewById(R.id.textCaption)
        textInfo = findViewById(R.id.textInfo)
        btnPlay = findViewById(R.id.btnPlay)
        seekRow = findViewById(R.id.seekRow)
        seekBar = findViewById(R.id.seekBar)
        textPos = findViewById(R.id.textPos)
        textDur = findViewById(R.id.textDur)

        val scale = if (prefs.fill) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
        imageA.scaleType = scale
        imageB.scaleType = scale

        setupPlayer()

        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<View>(R.id.btnNext).setOnClickListener { goNext(manual = true); pokeOverlay() }
        findViewById<View>(R.id.btnPrev).setOnClickListener { goPrev(); pokeOverlay() }
        btnPlay.setOnClickListener {
            userPaused = !userPaused
            if (userPaused) pauseShow() else resumeShow()
            updatePlayButton()
            pokeOverlay()
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val dur = player.duration
                    if (dur > 0) textPos.text = fmt(dur * progress / 1000)
                }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {
                dragging = true
                main.removeCallbacks(hideOverlay)
            }
            override fun onStopTrackingTouch(sb: SeekBar) {
                dragging = false
                val dur = player.duration
                if (dur > 0) player.seekTo(dur * sb.progress / 1000)
                pokeOverlay()
            }
        })

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                toggleOverlay()
                return true
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (abs(vx) > abs(vy) && abs(vx) > 600) {
                    if (vx < 0) goNext(manual = true) else goPrev()
                    return true
                }
                return false
            }
        })
        findViewById<View>(R.id.root).setOnTouchListener { v, ev ->
            if (ev.action == MotionEvent.ACTION_UP) v.performClick()
            detector.onTouchEvent(ev)
            true
        }

        scanner = Executors.newSingleThreadExecutor()
        // Deux chargements en parallèle : le suivant arrive même si un gros fichier traîne
        loader = Executors.newFixedThreadPool(2)

        textStatus.text = getString(R.string.searching)
        startScan()
    }

    private fun setupPlayer() {
        val dsFactory = DataSource.Factory { SmbDataSource(prefs) }
        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dsFactory))
            .build()
        player.setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(),
            prefs.videoSound
        )
        player.volume = if (prefs.videoSound) 1f else 0f
        player.repeatMode = if (prefs.autoNext) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ONE
        playerView.player = player
        playerView.resizeMode = if (prefs.fill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM
        else AspectRatioFrameLayout.RESIZE_MODE_FIT

        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && current is Prepared.Video) onMediaFinished()
                if (state == Player.STATE_READY) updateProgress()
            }
            override fun onPlayerError(error: PlaybackException) {
                val cur = current as? Prepared.Video ?: return
                failures++
                if (failures > 25) {
                    textStatus.text = getString(R.string.load_failed)
                    textStatus.visibility = View.VISIBLE
                    return
                }
                Toast.makeText(this@SlideshowActivity, R.string.video_error, Toast.LENGTH_SHORT).show()
                images.remove(cur.url)
                goNext(manual = false)
            }
        })
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onPause() {
        super.onPause()
        pauseShow()
    }

    override fun onResume() {
        super.onResume()
        if (!userPaused) resumeShow()
    }

    override fun onDestroy() {
        super.onDestroy()
        destroyed = true
        wanted = emptySet()
        main.removeCallbacksAndMessages(null)
        running.forEach { it.cancel() }
        stopAnim()
        player.release()
        scanner.shutdownNow()
        loader.shutdownNow()
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    // ---------- Recherche des fichiers ----------

    private fun startScan() {
        val roots = prefs.folders
        val recursive = prefs.subfolders
        val videos = prefs.includeVideos
        scanner.execute {
            Smb.scan(
                prefs, roots, recursive, videos,
                cancelled = { destroyed },
                onBatch = { batch -> main.post { onFound(batch) } },
                onError = { _, t -> main.post { scanErrors++; lastScanError = Smb.explain(t) } }
            )
            main.post {
                if (images.isEmpty() && !destroyed) {
                    textStatus.text = if (scanErrors > 0) lastScanError else getString(R.string.no_photo)
                }
            }
        }
    }

    private fun onFound(batch: List<String>) {
        if (destroyed) return
        val wasEmpty = images.isEmpty()
        images.addAll(batch)
        if (wasEmpty && current == null) {
            target = -1
            goTo(0, forward = true, manual = false)
        }
        if (shownCount == 0) textStatus.text = getString(R.string.searching_count, images.size)
    }

    // ---------- Liste de lecture ----------

    /** Choisit un nouvel élément à ajouter à la fin de la liste de lecture. */
    private fun chooseNew(): String? {
        if (images.isEmpty()) return null
        if (!prefs.random) {
            seqIndex = (seqIndex + 1) % images.size
            return images[seqIndex]
        }
        if (images.size == 1) return images[0]
        val ahead = HashSet<String>()
        for (i in max(0, histPos) until history.size) ahead.add(history[i])
        if (played.size + ahead.size >= images.size) played.clear()
        repeat(40) {
            val u = images[Random.nextInt(images.size)]
            if (u !in played && u !in ahead) return u
        }
        return images.firstOrNull { it !in played && it !in ahead }
            ?: images.firstOrNull { it != history.lastOrNull() }
            ?: images[0]
    }

    private fun ensurePlanned(upTo: Int) {
        while (history.size <= upTo) {
            val u = chooseNew() ?: return
            history.add(u)
        }
    }

    /**
     * Met à jour la « fenêtre » d'éléments utiles (actuel, 2 précédents, 2 suivants),
     * libère les autres et lance les chargements manquants, le plus urgent d'abord.
     */
    private fun refreshWindow() {
        val center = if (target >= 0) target else max(histPos, 0)
        ensurePlanned(center + AHEAD)
        if (history.isEmpty()) return
        val w = HashSet<String>()
        for (i in max(0, center - BEHIND)..min(history.size - 1, center + AHEAD)) w.add(history[i])
        history.getOrNull(histPos)?.let { w.add(it) }
        wanted = w
        cache.keys.retainAll(w)
        for (i in listOf(center, center + 1, center - 1, center + 2)) {
            history.getOrNull(i)?.let { request(it) }
        }
    }

    private fun request(url: String) {
        if (cache.containsKey(url) || inFlight.contains(url)) return
        if (Smb.isVideo(url)) {
            // Les vidéos se lisent en continu depuis le NAS : rien à précharger
            cache[url] = Prepared.Video(url)
            return
        }
        inFlight.add(url)
        val w = stage.width.takeIf { it > 0 } ?: resources.displayMetrics.widthPixels
        val h = stage.height.takeIf { it > 0 } ?: resources.displayMetrics.heightPixels
        loader.execute {
            // Devenu inutile entre-temps (on a avancé/reculé) : on ne télécharge pas
            if (url !in wanted) {
                main.post {
                    inFlight.remove(url)
                    if (!destroyed && url in wanted) request(url)
                }
                return@execute
            }
            var error: Throwable? = null
            val item: Prepared? = try {
                var res: Prepared? = null
                if (Smb.isGif(url) && Build.VERSION.SDK_INT >= 28) {
                    when (val d = Smb.loadAnimated(prefs, url, w, h)) {
                        is AnimatedImageDrawable -> res = Prepared.Anim(url, d)
                        is BitmapDrawable -> res = Prepared.Still(url, d.bitmap)
                        else -> {}
                    }
                }
                res ?: Smb.loadBitmap(prefs, url, w, h)?.let { b -> Prepared.Still(url, b) }
            } catch (t: Throwable) {
                error = t
                null
            }
            main.post {
                inFlight.remove(url)
                if (destroyed) return@post
                if (item != null) {
                    failures = 0
                    if (url in wanted) cache[url] = item
                    checkTarget()
                } else {
                    onLoadFailed(url, error)
                }
            }
        }
    }

    /** Fichier illisible : on le retire de la liste et on continue. */
    private fun onLoadFailed(url: String, err: Throwable?) {
        failures++
        images.remove(url)
        var i = history.size - 1
        while (i >= 0) {
            if (history[i] == url && i != histPos) {
                history.removeAt(i)
                if (i < histPos) histPos--
                if (target > i) target--
            }
            i--
        }
        if (failures > 25 || images.isEmpty()) {
            spinner.visibility = View.GONE
            textStatus.text = if (err != null) Smb.explain(err) else getString(R.string.load_failed)
            textStatus.visibility = View.VISIBLE
            return
        }
        refreshWindow()
        checkTarget()
    }

    // ---------- Navigation ----------

    private fun goNext(manual: Boolean) {
        val base = if (target >= 0) target else histPos
        goTo(base + 1, forward = true, manual = manual)
    }

    private fun goPrev() {
        val base = if (target >= 0) target else histPos
        if (base - 1 < 0) return
        goTo(base - 1, forward = false, manual = true)
    }

    private fun goTo(pos: Int, forward: Boolean, manual: Boolean) {
        main.removeCallbacks(tick)
        pendingAdvance = false
        ensurePlanned(pos)
        if (pos < 0 || pos >= history.size) return
        target = pos
        targetForward = forward
        targetManual = manual
        refreshWindow()
        if (!checkTarget()) {
            main.removeCallbacks(showSpinner)
            main.postDelayed(showSpinner, 350)
        }
    }

    /** Affiche l'élément attendu s'il est prêt. */
    private fun checkTarget(): Boolean {
        if (target < 0) return false
        val url = history.getOrNull(target) ?: return false
        val item = cache[url] ?: return false
        val pos = target
        target = -1
        main.removeCallbacks(showSpinner)
        spinner.visibility = View.GONE
        histPos = pos
        played.add(url)
        // Limite la taille de la liste de lecture
        if (history.size > 400 && histPos > 100) {
            repeat(100) { history.removeAt(0) }
            histPos -= 100
        }
        display(item, targetForward, if (targetManual) FAST_MS else TRANSITION_MS)
        refreshWindow()
        return true
    }

    /** Fin d'une vidéo ou d'un GIF. */
    private fun onMediaFinished() {
        if (!prefs.autoNext) return
        if (paused) {
            pendingAdvance = true
            return
        }
        goNext(manual = false)
    }

    private fun scheduleTick(transitionMs: Long) {
        main.removeCallbacks(tick)
        if (!paused && current is Prepared.Still) {
            main.postDelayed(tick, prefs.intervalSec * 1000L + transitionMs)
        }
    }

    private fun pauseShow() {
        paused = true
        main.removeCallbacks(tick)
        running.forEach { if (it.isRunning) it.pause() }
        if (current is Prepared.Video) player.pause()
        if (Build.VERSION.SDK_INT >= 28) (currentAnim as? AnimatedImageDrawable)?.stop()
    }

    private fun resumeShow() {
        if (!paused) return
        paused = false
        running.forEach { if (it.isPaused) it.resume() }
        when (current) {
            is Prepared.Video -> player.play()
            is Prepared.Anim -> if (Build.VERSION.SDK_INT >= 28) (currentAnim as? AnimatedImageDrawable)?.start()
            is Prepared.Still -> scheduleTick(0)
            null -> {}
        }
        if (pendingAdvance) goNext(manual = false)
    }

    // ---------- Affichage et transitions ----------

    private fun stopAnim() {
        if (Build.VERSION.SDK_INT >= 28) {
            (currentAnim as? AnimatedImageDrawable)?.let {
                it.clearAnimationCallbacks()
                it.stop()
            }
        }
        currentAnim = null
    }

    private fun stopVideo() {
        player.stop()
        player.clearMediaItems()
        playerView.visibility = View.INVISIBLE
        resetView(playerView)
    }

    private fun display(item: Prepared, forward: Boolean, durationMs: Long) {
        // Termine net la transition précédente (évite les images à moitié animées)
        val previous = ArrayList(running)
        running.clear()
        previous.forEach { it.end() }
        main.removeCallbacks(tick)
        stopAnim()
        pendingAdvance = false

        val outgoing = currentView
        val incoming: View = when (item) {
            is Prepared.Video -> playerView
            else -> if (outgoing === imageA) imageB else imageA
        }

        // Nettoie ce qui n'est ni l'ancien ni le nouvel élément
        if (playerView !== outgoing && playerView !== incoming) stopVideo()
        for (iv in listOf(imageA, imageB)) {
            if (iv !== outgoing && iv !== incoming) {
                iv.setImageDrawable(null)
                resetView(iv)
            }
        }
        outgoing?.let { resetView(it) }

        resetView(incoming)
        incoming.visibility = View.VISIBLE
        when (item) {
            is Prepared.Still -> (incoming as ImageView).setImageBitmap(item.bmp)
            is Prepared.Anim -> {
                (incoming as ImageView).setImageDrawable(item.drawable)
                if (Build.VERSION.SDK_INT >= 28) startAnim(item.drawable as AnimatedImageDrawable)
            }
            is Prepared.Video -> startVideo(item.url)
        }
        incoming.bringToFront()
        current = item
        currentView = incoming

        textStatus.visibility = View.GONE
        shownCount++

        val name = Smb.pretty(item.url)
        textInfo.text = name
        if (prefs.showName) {
            textCaption.visibility = View.VISIBLE
            textCaption.text = name.substringAfterLast('/')
            textCaption.bringToFront()
        } else {
            textCaption.visibility = View.GONE
        }
        val isVideo = item is Prepared.Video
        seekRow.visibility = if (isVideo) View.VISIBLE else View.GONE
        if (isVideo && overlay.visibility == View.VISIBLE) {
            main.removeCallbacks(progressTick)
            main.post(progressTick)
        }
        spinner.bringToFront()
        overlay.bringToFront()

        var type = prefs.transition
        if (type == Transitions.RANDOM) type = listOf(
            Transitions.FADE, Transitions.SLIDE, Transitions.ZOOM, Transitions.KEN_BURNS
        ).random()
        if (shownCount == 1 && type == Transitions.SLIDE) type = Transitions.FADE
        // Le mouvement lent ne s'applique qu'aux photos fixes
        if (type == Transitions.KEN_BURNS && item !is Prepared.Still) type = Transitions.FADE
        // Vidéo suivie d'une vidéo : même lecteur, pas de transition possible
        if (incoming === outgoing) type = Transitions.NONE

        val w = stage.width.toFloat().takeIf { it > 0 } ?: resources.displayMetrics.widthPixels.toFloat()
        val dir = if (forward) 1f else -1f
        val anims = ArrayList<Animator>()

        when (type) {
            Transitions.FADE, Transitions.KEN_BURNS -> {
                anims += ObjectAnimator.ofFloat(incoming, View.ALPHA, 0f, 1f)
            }
            Transitions.SLIDE -> {
                anims += ObjectAnimator.ofFloat(incoming, View.TRANSLATION_X, w * dir, 0f)
                if (outgoing != null) anims += ObjectAnimator.ofFloat(outgoing, View.TRANSLATION_X, 0f, -w * dir)
            }
            Transitions.ZOOM -> {
                anims += ObjectAnimator.ofFloat(incoming, View.ALPHA, 0f, 1f)
                anims += ObjectAnimator.ofFloat(incoming, View.SCALE_X, 1.25f, 1f)
                anims += ObjectAnimator.ofFloat(incoming, View.SCALE_Y, 1.25f, 1f)
            }
            else -> { /* aucune transition */ }
        }

        if (anims.isNotEmpty()) {
            val set = AnimatorSet().apply {
                playTogether(anims)
                duration = durationMs
                interpolator = DecelerateInterpolator()
            }
            running += set
            set.start()
        }

        if (type == Transitions.KEN_BURNS) {
            // Lent zoom avec léger déplacement pendant tout l'affichage
            val total = prefs.intervalSec * 1000L + durationMs * 2
            val zoomIn = Random.nextBoolean()
            val from = if (zoomIn) 1.0f else 1.15f
            val to = if (zoomIn) 1.15f else 1.0f
            val shift = w * 0.04f * (if (Random.nextBoolean()) 1 else -1)
            val kb = AnimatorSet().apply {
                playTogether(
                    ObjectAnimator.ofFloat(incoming, View.SCALE_X, from, to),
                    ObjectAnimator.ofFloat(incoming, View.SCALE_Y, from, to),
                    ObjectAnimator.ofFloat(incoming, View.TRANSLATION_X, -shift / 2, shift / 2)
                )
                duration = total
                interpolator = LinearInterpolator()
            }
            running += kb
            kb.start()
        }

        if (paused) running.forEach { it.pause() }

        // Libère l'ancien élément une fois la transition terminée
        val gen = shownCount
        main.postDelayed({
            if (gen == shownCount && !destroyed && outgoing != null && outgoing !== incoming) {
                if (outgoing === playerView) stopVideo()
                else if (outgoing is ImageView) {
                    outgoing.setImageDrawable(null)
                    resetView(outgoing)
                }
            }
        }, durationMs + 100)

        scheduleTick(durationMs)
    }

    @RequiresApi(28)
    private fun startAnim(d: AnimatedImageDrawable) {
        d.repeatCount = if (prefs.autoNext) 0 else AnimatedImageDrawable.REPEAT_INFINITE
        d.registerAnimationCallback(object : Animatable2.AnimationCallback() {
            override fun onAnimationEnd(drawable: Drawable?) {
                if (drawable === currentAnim) main.post { onMediaFinished() }
            }
        })
        currentAnim = d
        if (!paused) d.start()
    }

    private fun startVideo(url: String) {
        player.setMediaItem(MediaItem.fromUri(Smb.videoUri(url)))
        player.prepare()
        player.playWhenReady = !paused
    }

    private fun resetView(v: View) {
        v.alpha = 1f
        v.translationX = 0f
        v.scaleX = 1f
        v.scaleY = 1f
    }

    // ---------- Commandes ----------

    private fun toggleOverlay() {
        if (overlay.visibility == View.VISIBLE) {
            main.removeCallbacks(hideOverlay)
            overlay.visibility = View.GONE
        } else {
            overlay.visibility = View.VISIBLE
            overlay.bringToFront()
            updatePlayButton()
            main.removeCallbacks(progressTick)
            main.post(progressTick)
            pokeOverlay()
        }
    }

    private fun pokeOverlay() {
        main.removeCallbacks(hideOverlay)
        if (!dragging) main.postDelayed(hideOverlay, if (current is Prepared.Video) 5000 else 4000)
    }

    private fun updateProgress() {
        if (current !is Prepared.Video || dragging) return
        val dur = player.duration
        val pos = player.currentPosition
        if (dur > 0 && dur != C.TIME_UNSET) {
            textDur.text = fmt(dur)
            textPos.text = fmt(pos)
            seekBar.progress = (pos * 1000 / dur).toInt()
        } else {
            textDur.text = "–:––"
            textPos.text = fmt(pos)
            seekBar.progress = 0
        }
    }

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%d:%02d", m, sec)
    }

    private fun updatePlayButton() {
        btnPlay.setImageResource(
            if (userPaused) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause
        )
        btnPlay.contentDescription = getString(if (userPaused) R.string.play else R.string.pause)
    }

    companion object {
        private const val TRANSITION_MS = 1000L
        /** Transition plus courte quand on passe soi-même au suivant/précédent. */
        private const val FAST_MS = 350L
        private const val AHEAD = 2
        private const val BEHIND = 2
    }
}
