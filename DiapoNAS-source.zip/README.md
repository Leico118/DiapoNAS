# DiapoNAS

Diaporama Android de photos stockées sur un NAS (Synology, y compris anciens modèles en SMB1/SMB2).

- Choix de plusieurs dossiers du NAS
- Ordre aléatoire ou dans l'ordre, sous-dossiers inclus ou non
- Durée par photo réglable (3 s à 2 min)
- Transitions : fondu, glissement, zoom, Ken Burns, aléatoire ou aucune
- Glisser à gauche / à droite pour changer de photo, toucher l'écran pour les commandes

L'APK est compilé automatiquement par GitHub Actions et publié dans « Releases ».
